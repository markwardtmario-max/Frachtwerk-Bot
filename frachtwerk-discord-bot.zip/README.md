# Frachtwerk Discord Bot 🚚

Discord-Bot für die Verwaltung von Frachtaufträgen und Touren.

## Funktionen

### Aufträge
- `/auftrag erstellen`
- `/auftrag liste`
- `/auftrag anzeigen`
- `/auftrag übernehmen`
- `/auftrag status`

### Touren
- `/tour erstellen`
- `/tour liste`
- `/tour anzeigen`
- `/tour start`
- `/tour abschluss`

Die Daten werden in `data/db.json` gespeichert und bleiben nach einem Neustart erhalten.

## Voraussetzungen

Die aktuelle discord.js-Dokumentation nennt Node.js 24.17.0 oder neuer als Voraussetzung. Verwende deshalb eine aktuelle Node-24-Version.

## Einrichtung

1. Erstelle im Discord Developer Portal eine neue Application.
2. Erstelle unter der Application einen Bot und kopiere den Bot-Token.
3. Kopiere `.env.example` nach `.env`.
4. Trage `DISCORD_TOKEN`, `CLIENT_ID` und `GUILD_ID` ein.
5. Installiere die Pakete:

```bash
npm install
```

6. Registriere die Slash-Commands:

```bash
npm run deploy
```

7. Starte den Bot:

```bash
npm start
```

## Berechtigungen

Für `/auftrag erstellen` und `/tour erstellen` benötigt der Benutzer `Server verwalten` oder `Administrator`.

Fahrer können Aufträge übernehmen und deren Status ändern. Dafür muss ihre Discord-Rolle `Fahrer`, `Dispatcher` oder `Disponent` heißen.

## Discord Bot einladen

Beim OAuth2-Installieren mindestens die Scopes `bot` und `applications.commands` auswählen. Der Bot braucht auf dem Server nur die Berechtigungen, die er tatsächlich benötigt, insbesondere Nachrichten senden und Einbettungen verwenden.

## Beispielablauf

```text
/auftrag erstellen
kunde: Spedition Müller
abholung: Hannover
lieferung: Hamburg
ladung: Paletten
gewicht: 18
lohn: 850

/auftrag übernehmen nummer: 1001

/tour erstellen
name: Nordtour 01
fahrer: Max
lkw: MAN TGX
auftraege: 1001
startzeit: 08:00

/tour start nummer: 101

/tour abschluss nummer: 101
```

## Erweiterungen für Version 2

- Fahrerprofile und Fuhrpark
- automatische Tourberechnung
- Buttons statt Slash-Befehle
- eigene Auftragskanäle
- Rechnungs-/Lohnübersicht
- Kilometer- und Mautberechnung
- Rollen automatisch vergeben
- Web-Dashboard
- MySQL/PostgreSQL statt JSON
- Logs und Admin-Statistik

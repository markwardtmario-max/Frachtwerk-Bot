import {
  SlashCommandBuilder,
  EmbedBuilder,
  PermissionFlagsBits
} from "discord.js";
import { loadDb, saveDb, nextNumber } from "./db.js";
import { requireManager, requireDriver } from "./permissions.js";

const orderStatuses = ["OFFEN", "ÜBERNOMMEN", "IN_TRANSPORT", "ERLEDIGT", "STORNIERT"];
const tourStatuses = ["GEPLANT", "GESTARTET", "ABGESCHLOSSEN", "ABGEBROCHEN"];

function money(value) {
  return `${Number(value || 0).toFixed(2).replace(".", ",")} €`;
}

function orderLabel(o) {
  return `FW-${o.id}`;
}

function tourLabel(t) {
  return `T-${t.id}`;
}

export const commands = [
  new SlashCommandBuilder()
    .setName("auftrag")
    .setDescription("Frachtwerk-Aufträge verwalten")
    .addSubcommand(sub => sub
      .setName("erstellen")
      .setDescription("Neuen Frachtauftrag erstellen")
      .addStringOption(o => o.setName("kunde").setDescription("Kunde/Auftraggeber").setRequired(true))
      .addStringOption(o => o.setName("abholung").setDescription("Abholort").setRequired(true))
      .addStringOption(o => o.setName("lieferung").setDescription("Lieferort").setRequired(true))
      .addStringOption(o => o.setName("ladung").setDescription("Ladung").setRequired(true))
      .addNumberOption(o => o.setName("gewicht").setDescription("Gewicht in Tonnen").setMinValue(0).setRequired(false))
      .addNumberOption(o => o.setName("lohn").setDescription("Auftragswert in Euro").setMinValue(0).setRequired(false))
      .addStringOption(o => o.setName("notiz").setDescription("Zusätzliche Infos").setRequired(false)))
    .addSubcommand(sub => sub
      .setName("liste")
      .setDescription("Aufträge anzeigen")
      .addStringOption(o => o.setName("status").setDescription("Nach Status filtern").setRequired(false)
        .addChoices(...orderStatuses.map(s => ({ name: s, value: s })))))
    .addSubcommand(sub => sub
      .setName("anzeigen")
      .setDescription("Einen Auftrag anzeigen")
      .addIntegerOption(o => o.setName("nummer").setDescription("Auftragsnummer, z.B. 1001").setRequired(true)))
    .addSubcommand(sub => sub
      .setName("übernehmen")
      .setDescription("Einen offenen Auftrag übernehmen")
      .addIntegerOption(o => o.setName("nummer").setDescription("Auftragsnummer").setRequired(true)))
    .addSubcommand(sub => sub
      .setName("status")
      .setDescription("Status eines Auftrags ändern")
      .addIntegerOption(o => o.setName("nummer").setDescription("Auftragsnummer").setRequired(true))
      .addStringOption(o => o.setName("status").setDescription("Neuer Status").setRequired(true)
        .addChoices(...orderStatuses.map(s => ({ name: s, value: s })) ))),

  new SlashCommandBuilder()
    .setName("tour")
    .setDescription("Frachtwerk-Touren planen und verwalten")
    .addSubcommand(sub => sub
      .setName("erstellen")
      .setDescription("Neue Tour aus Aufträgen planen")
      .addStringOption(o => o.setName("name").setDescription("Name der Tour").setRequired(true))
      .addStringOption(o => o.setName("fahrer").setDescription("Fahrer-Name oder Discord-Name").setRequired(true))
      .addStringOption(o => o.setName("lkw").setDescription("LKW/Truck").setRequired(true))
      .addStringOption(o => o.setName("auftraege").setDescription("Auftragsnummern, z.B. 1001,1002,1005").setRequired(true))
      .addStringOption(o => o.setName("startzeit").setDescription("Geplante Startzeit").setRequired(false))
      .addStringOption(o => o.setName("notiz").setDescription("Tour-Notiz").setRequired(false)))
    .addSubcommand(sub => sub
      .setName("liste")
      .setDescription("Touren anzeigen")
      .addStringOption(o => o.setName("status").setDescription("Nach Status filtern").setRequired(false)
        .addChoices(...tourStatuses.map(s => ({ name: s, value: s })))))
    .addSubcommand(sub => sub
      .setName("anzeigen")
      .setDescription("Eine Tour anzeigen")
      .addIntegerOption(o => o.setName("nummer").setDescription("Tournummer, z.B. 101").setRequired(true)))
    .addSubcommand(sub => sub
      .setName("start")
      .setDescription("Tour starten")
      .addIntegerOption(o => o.setName("nummer").setDescription("Tournummer").setRequired(true)))
    .addSubcommand(sub => sub
      .setName("abschluss")
      .setDescription("Tour abschließen")
      .addIntegerOption(o => o.setName("nummer").setDescription("Tournummer").setRequired(true)))
];

export async function handleCommand(interaction) {
  const group = interaction.commandName;
  const sub = interaction.options.getSubcommand();
  const db = loadDb();

  if (group === "auftrag") {
    if (sub === "erstellen") {
      const error = requireManager(interaction);
      if (error) return interaction.reply({ content: error, ephemeral: true });

      const order = {
        id: nextNumber(db, "order"),
        customer: interaction.options.getString("kunde"),
        pickup: interaction.options.getString("abholung"),
        delivery: interaction.options.getString("lieferung"),
        cargo: interaction.options.getString("ladung"),
        weight: interaction.options.getNumber("gewicht") ?? 0,
        pay: interaction.options.getNumber("lohn") ?? 0,
        note: interaction.options.getString("notiz") ?? "",
        status: "OFFEN",
        driverId: null,
        driverName: null,
        tourId: null,
        createdBy: interaction.user.id,
        createdAt: new Date().toISOString()
      };

      db.orders.push(order);
      saveDb(db);

      const embed = new EmbedBuilder()
        .setTitle(`📦 Auftrag ${orderLabel(order)}`)
        .setDescription("Neuer Frachtauftrag wurde erstellt.")
        .addFields(
          { name: "Kunde", value: order.customer, inline: true },
          { name: "Abholung", value: order.pickup, inline: true },
          { name: "Lieferung", value: order.delivery, inline: true },
          { name: "Ladung", value: order.cargo, inline: true },
          { name: "Gewicht", value: `${order.weight} t`, inline: true },
          { name: "Auftragswert", value: money(order.pay), inline: true },
          { name: "Status", value: order.status, inline: true }
        )
        .setTimestamp();

      return interaction.reply({ embeds: [embed] });
    }

    if (sub === "liste") {
      const filter = interaction.options.getString("status");
      const orders = db.orders
        .filter(o => !filter || o.status === filter)
        .slice(-15)
        .reverse();

      if (!orders.length) return interaction.reply("Keine Aufträge gefunden.");

      const lines = orders.map(o =>
        `**${orderLabel(o)}** · ${o.status} · ${o.pickup} → ${o.delivery} · ${o.cargo}` +
        (o.driverName ? ` · Fahrer: ${o.driverName}` : "")
      );
      return interaction.reply(lines.join("\n"));
    }

    if (sub === "anzeigen") {
      const id = interaction.options.getInteger("nummer");
      const o = db.orders.find(x => x.id === id);
      if (!o) return interaction.reply({ content: "Auftrag nicht gefunden.", ephemeral: true });

      const tour = o.tourId ? db.tours.find(t => t.id === o.tourId) : null;
      const embed = new EmbedBuilder()
        .setTitle(`📦 Auftrag ${orderLabel(o)}`)
        .addFields(
          { name: "Kunde", value: o.customer, inline: true },
          { name: "Status", value: o.status, inline: true },
          { name: "Fahrer", value: o.driverName ?? "Noch nicht übernommen", inline: true },
          { name: "Abholung", value: o.pickup, inline: true },
          { name: "Lieferung", value: o.delivery, inline: true },
          { name: "Ladung", value: `${o.cargo}${o.weight ? ` (${o.weight} t)` : ""}`, inline: true },
          { name: "Auftragswert", value: money(o.pay), inline: true },
          { name: "Tour", value: tour ? tourLabel(tour) : "Noch keiner Tour zugeordnet", inline: true },
          { name: "Notiz", value: o.note || "Keine", inline: false }
        )
        .setTimestamp(new Date(o.createdAt));

      return interaction.reply({ embeds: [embed] });
    }

    if (sub === "übernehmen") {
      const error = requireDriver(interaction);
      if (error) return interaction.reply({ content: error, ephemeral: true });

      const id = interaction.options.getInteger("nummer");
      const o = db.orders.find(x => x.id === id);
      if (!o) return interaction.reply({ content: "Auftrag nicht gefunden.", ephemeral: true });
      if (o.status !== "OFFEN") return interaction.reply({ content: `Der Auftrag ist bereits **${o.status}**.`, ephemeral: true });

      o.status = "ÜBERNOMMEN";
      o.driverId = interaction.user.id;
      o.driverName = interaction.member?.displayName ?? interaction.user.username;
      saveDb(db);

      return interaction.reply(`🚚 **${orderLabel(o)}** wurde von **${o.driverName}** übernommen.`);
    }

    if (sub === "status") {
      const error = requireDriver(interaction);
      if (error) return interaction.reply({ content: error, ephemeral: true });

      const id = interaction.options.getInteger("nummer");
      const status = interaction.options.getString("status");
      const o = db.orders.find(x => x.id === id);
      if (!o) return interaction.reply({ content: "Auftrag nicht gefunden.", ephemeral: true });

      const manager = interaction.memberPermissions?.has(PermissionFlagsBits.ManageGuild);
      if (!manager && o.driverId !== interaction.user.id) {
        return interaction.reply({ content: "Du kannst nur Aufträge ändern, die du selbst übernommen hast.", ephemeral: true });
      }

      o.status = status;
      saveDb(db);
      return interaction.reply(`📦 **${orderLabel(o)}** steht jetzt auf **${status}**.`);
    }
  }

  if (group === "tour") {
    if (sub === "erstellen") {
      const error = requireManager(interaction);
      if (error) return interaction.reply({ content: error, ephemeral: true });

      const ids = interaction.options.getString("auftraege")
        .split(",")
        .map(x => Number(x.trim()))
        .filter(Number.isInteger);

      if (!ids.length) return interaction.reply({ content: "Bitte mindestens eine gültige Auftragsnummer angeben.", ephemeral: true });

      const selected = db.orders.filter(o => ids.includes(o.id));
      const missing = ids.filter(id => !selected.some(o => o.id === id));
      if (missing.length) return interaction.reply({ content: `Nicht gefunden: ${missing.map(id => orderLabel({id})).join(", ")}`, ephemeral: true });

      const alreadyAssigned = selected.filter(o => o.tourId);
      if (alreadyAssigned.length) {
        return interaction.reply({ content: `Bereits einer Tour zugeordnet: ${alreadyAssigned.map(orderLabel).join(", ")}`, ephemeral: true });
      }

      const tour = {
        id: nextNumber(db, "tour"),
        name: interaction.options.getString("name"),
        driver: interaction.options.getString("fahrer"),
        truck: interaction.options.getString("lkw"),
        orderIds: selected.map(o => o.id),
        startTime: interaction.options.getString("startzeit") ?? "Nicht angegeben",
        note: interaction.options.getString("notiz") ?? "",
        status: "GEPLANT",
        createdBy: interaction.user.id,
        createdAt: new Date().toISOString()
      };

      for (const o of selected) o.tourId = tour.id;
      db.tours.push(tour);
      saveDb(db);

      return interaction.reply(
        `🗺️ **${tourLabel(tour)} – ${tour.name}** wurde geplant.\n` +
        `Fahrer: **${tour.driver}** · LKW: **${tour.truck}** · Aufträge: ${selected.map(orderLabel).join(", ")}`
      );
    }

    if (sub === "liste") {
      const filter = interaction.options.getString("status");
      const tours = db.tours.filter(t => !filter || t.status === filter).slice(-15).reverse();
      if (!tours.length) return interaction.reply("Keine Touren gefunden.");

      return interaction.reply(tours.map(t =>
        `**${tourLabel(t)} – ${t.name}** · ${t.status} · 🚚 ${t.driver} · ${t.orderIds.map(id => orderLabel({id})).join(", ")}`
      ).join("\n"));
    }

    if (sub === "anzeigen") {
      const id = interaction.options.getInteger("nummer");
      const t = db.tours.find(x => x.id === id);
      if (!t) return interaction.reply({ content: "Tour nicht gefunden.", ephemeral: true });

      const orders = t.orderIds.map(id => db.orders.find(o => o.id === id)).filter(Boolean);
      const route = orders.length
        ? orders.map(o => `${o.pickup} → ${o.delivery}`).join("\n")
        : "Keine Aufträge";

      const embed = new EmbedBuilder()
        .setTitle(`🗺️ ${tourLabel(t)} – ${t.name}`)
        .addFields(
          { name: "Status", value: t.status, inline: true },
          { name: "Fahrer", value: t.driver, inline: true },
          { name: "LKW", value: t.truck, inline: true },
          { name: "Startzeit", value: t.startTime, inline: true },
          { name: "Aufträge", value: t.orderIds.map(id => orderLabel({id})).join(", ") || "Keine", inline: false },
          { name: "Route", value: route, inline: false },
          { name: "Notiz", value: t.note || "Keine", inline: false }
        )
        .setTimestamp(new Date(t.createdAt));

      return interaction.reply({ embeds: [embed] });
    }

    if (sub === "start" || sub === "abschluss") {
      const error = requireDriver(interaction);
      if (error) return interaction.reply({ content: error, ephemeral: true });

      const id = interaction.options.getInteger("nummer");
      const t = db.tours.find(x => x.id === id);
      if (!t) return interaction.reply({ content: "Tour nicht gefunden.", ephemeral: true });

      const isManager = interaction.memberPermissions?.has(PermissionFlagsBits.ManageGuild);
      const driverMatches = t.driver.toLowerCase().includes((interaction.member?.displayName ?? "").toLowerCase()) ||
        t.driver.toLowerCase().includes(interaction.user.username.toLowerCase());

      if (!isManager && !driverMatches) {
        return interaction.reply({ content: "Diese Tour ist keinem passenden Fahrer zugeordnet.", ephemeral: true });
      }

      if (sub === "start") {
        if (t.status !== "GEPLANT") return interaction.reply({ content: `Tour ist bereits **${t.status}**.`, ephemeral: true });
        t.status = "GESTARTET";
        for (const id of t.orderIds) {
          const o = db.orders.find(x => x.id === id);
          if (o && o.status !== "ERLEDIGT") o.status = "IN_TRANSPORT";
        }
        saveDb(db);
        return interaction.reply(`🚛 **${tourLabel(t)} – ${t.name}** wurde gestartet.`);
      }

      if (t.status !== "GESTARTET") return interaction.reply({ content: `Tour kann nur aus **GESTARTET** abgeschlossen werden.`, ephemeral: true });
      t.status = "ABGESCHLOSSEN";
      for (const id of t.orderIds) {
        const o = db.orders.find(x => x.id === id);
        if (o) o.status = "ERLEDIGT";
      }
      saveDb(db);
      return interaction.reply(`✅ **${tourLabel(t)} – ${t.name}** wurde abgeschlossen. Zugehörige Aufträge wurden auf **ERLEDIGT** gesetzt.`);
    }
  }
}

import "dotenv/config";
import { REST, Routes } from "discord.js";
import { commands } from "./commands.js";

if (!process.env.DISCORD_TOKEN || !process.env.CLIENT_ID || !process.env.GUILD_ID) {
  throw new Error("DISCORD_TOKEN, CLIENT_ID und GUILD_ID müssen in .env gesetzt sein.");
}

const rest = new REST({ version: "10" }).setToken(process.env.DISCORD_TOKEN);

await rest.put(
  Routes.applicationGuildCommands(process.env.CLIENT_ID, process.env.GUILD_ID),
  { body: commands.map(command => command.toJSON()) }
);

console.log("Frachtwerk-Slash-Commands wurden auf dem Server registriert.");

import "dotenv/config";
import {
  Client,
  Events,
  GatewayIntentBits
} from "discord.js";
import { handleCommand } from "./commands.js";

if (!process.env.DISCORD_TOKEN) {
  throw new Error("DISCORD_TOKEN fehlt in der .env-Datei.");
}

const client = new Client({
  intents: [GatewayIntentBits.Guilds]
});

client.once(Events.ClientReady, readyClient => {
  console.log(`Frachtwerk Bot online als ${readyClient.user.tag}`);
});

client.on(Events.InteractionCreate, async interaction => {
  if (!interaction.isChatInputCommand()) return;

  try {
    await handleCommand(interaction);
  } catch (error) {
    console.error(error);
    const message = "Beim Ausführen des Befehls ist ein Fehler aufgetreten.";
    if (interaction.replied || interaction.deferred) {
      await interaction.followUp({ content: message, ephemeral: true }).catch(() => {});
    } else {
      await interaction.reply({ content: message, ephemeral: true }).catch(() => {});
    }
  }
});

process.on("unhandledRejection", console.error);
process.on("uncaughtException", console.error);

client.login(process.env.DISCORD_TOKEN);

import { PermissionFlagsBits } from "discord.js";

export function isManager(interaction) {
  return interaction.memberPermissions?.has(PermissionFlagsBits.ManageGuild) ||
    interaction.memberPermissions?.has(PermissionFlagsBits.Administrator);
}

export function isDriver(interaction) {
  if (isManager(interaction)) return true;
  const roles = interaction.member?.roles?.cache;
  return roles?.some(role => /fahrer|dispatcher|disponent/i.test(role.name)) ?? false;
}

export function requireManager(interaction) {
  if (!isManager(interaction)) {
    return "Dafür brauchst du die Server-Berechtigung **Server verwalten** oder **Administrator**.";
  }
  return null;
}

export function requireDriver(interaction) {
  if (!isDriver(interaction)) {
    return "Dafür brauchst du die Rolle **Fahrer**, **Dispatcher** oder **Disponent**.";
  }
  return null;
}
